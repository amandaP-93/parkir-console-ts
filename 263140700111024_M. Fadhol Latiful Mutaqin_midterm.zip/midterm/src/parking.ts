import * as readline from "readline";

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

console.log(" ============================================ ")
console.log("           SISTEM HITUNG RENTAL PARKIR        ")
console.log(" ============================================ ")

//deklarasi tarif dasar dan tarif perjam berikutnya

const BASE_MOTOR: number = 3000;
const TarifTambahan_MOTOR: number = 2000;

const BASE_MOBIL: number = 5000;
const TarifTambahan_MOBIL: number = 3000;

const BASE_TRUK: number = 7000;
const TarifTambahan_TRUK: number = 4000;

const BiayaAdmin: number = 1000;

console.log(" ============================================ ")
console.log("           SISTEM HITUNG RENTAL PARKIR        ")
console.log(" ============================================ ")

//input 1: Nama Pengendara (tipe data string)
rl.question("Masukkan Nama Pengendara : ", (namaPengendara: string)=>{
    //input 2: Plat Nomor (tipe data string)
    rl.question("Masukkan Plat Nomor    : ", (platNomor: string) => {
        //input 3: Durasi Parkir (tipe data number)
        rl.question("Masukkan Durasi Parkir (jam): ", (inpurDurasi: string) => {
            let durasiParkir: number = Number(inpurDurasi);

            // Inpur 4: status Member (tipe data boolean)
            rl.question("Apakah Member Parkir? (y/n): ", (inputMember: string) => {
                //Operator Logika || dan perbandingan ===
                let isMember: boolean = 
                inputMember.toLowerCase() === "y" || inputMember.toLocaleLowerCase() === "ya";

                console.log("\nPilih Jenis Kendaraan:");
                console.log("1. Motor (Rp 3.000 / Jam ke-1, Rp 2.000 / jam berikutnya");
                console.log("2. Mobil (Rp 5.000 / Jam ke-1, Rp 3.000 / jam berikutnya");
                console.log("3. Truk (Rp 7.000 / Jam ke-1, Rp 4.000 / jam berikutnya");

                //input 5: Pilihan Kendaraan
                rl.question("pilihan kendaraan (1-3) : ", (inputKendaraan: string) => {
                    let jenisKendaraan: number = Number(inputKendaraan);

                    //deklarasi variable yang dapat berubah (let)
                    let baseRate: number = 0;
                    let tarifTambahan: number = 0;
                    let totalBiaya: number = 0;
                    let namaKendaraan: string = "";

                    // switch 1 (penggunaan switch pertama - mmin 3 case + default)
                    // nesting level 1: block switch utama
                    switch (jenisKendaraan){
                        case 1:
                            namaKendaraan = "Motor";
                            baseRate = BASE_MOTOR;
                            tarifTambahan = TarifTambahan_MOTOR;

                            // IF 1 (penggunaan IF pertama - Menghitung Durasi Parkir)
                            // Nesting level 2: IF di dalam case switch
                            if (durasiParkir <= 1){
                                totalBiaya = baseRate;
                            } else if (durasiParkir > 1 && isMember === true){
                                // kondiri majemuk menggunakan operator logika && dan perbandingan > & ===
                                // IF 2 (penggunaan IF kedua - diskon durasi panjang member)
                                // Nesting level 3: IF di dalam IF di dalam swithc (kedalaman 3 level)
                                if (durasiParkir >= 10) {
                                    console.log ("[Diskon Member Spesial] parkir >= 10 jam dapat potongan 20%!");
                                    let biayaNormal: number =
                                    baseRate + (durasiParkir - 1) * tarifTambahan;
                                    totalBiaya = biayaNormal * 0.8; // diskon 20%
                                } else {
                                    console.log("[Diskon Member] Parkir > 1 jam dapat Potongan 10%!");
                                    let biayaNormal: number =
                                    baseRate + (durasiParkir - 1) * tarifTambahan;
                                    totalBiaya = biayaNormal * 0.9; //diskon 10%
                                }
                            } else {
                                //perhitungan standar non member (durasi > 1 jam)
                                totalBiaya = baseRate + (durasiParkir - 1) * tarifTambahan
                            }
                            break;
                        case 2:
                            namaKendaraan = "Mobil";
                            baseRate = BASE_MOBIL;
                            tarifTambahan = TarifTambahan_MOBIL;
                            
                            if (durasiParkir <= 1){
                                totalBiaya = baseRate
                            } else {
                                totalBiaya = baseRate + (durasiParkir - 1) * tarifTambahan;

                                // penggunaan operator logika ! (NOT) dan || (OR)
                                if (isMember || !(durasiParkir < 5)){
                                    console.log("[Bonus Poin] Member atau parkir >= 5 jam mendapat voucher cuci mobil.");
                                }
                            }
                            break;
                         case 3:
                            namaKendaraan = "Truk";
                            baseRate = BASE_TRUK;
                            tarifTambahan = TarifTambahan_TRUK;
                            
                            if (durasiParkir <= 1){
                                totalBiaya = baseRate;
                            } else {
                                totalBiaya = baseRate + (durasiParkir - 1) * tarifTambahan;

                                // penggunaan operator modulus (%)
                                let sisaJam: number = durasiParkir % 2;
                                if ( sisaJam !== 0) {
                                    console.log("[catatan] Durasi parkir ganjil.");
                                }
                            }
                            break;
                        default:
                            console.log("pilihan kendaraan tidak valid!");
                            rl.close();
                            return;    
                    }
                    let penyesuaian: number = 1;
                    penyesuaian *= 1;
                    totalBiaya /= penyesuaian;

                    console.log("\n-----------------------------------------");
                    console.log("           RINGKASAN BIAYA PARKIR          ");
                    console.log("\n-----------------------------------------");
                    console.log(`Pengendara     : ${namaPengendara}`);
                    console.log(`Plat Nomor     : ${platNomor}`);
                    console.log(`Durasi Parkir  : ${durasiParkir} Jam`);
                    console.log(`Total Tarif    : Rp ${totalBiaya}`);

                    console.log("\nPilih Metode Pembayaran:");
                    console.log("1. Tunai (Cash):");
                    console.log("2. E-Money (+ Biaya admin 1.000):");
                    console.log("3. kartu Kredit (+ Surcharge 2%)");

                    // Input 6: Pilihan metode Pembayaran
                    rl.question("Pilihan Pembayaran (1-3) : ", (inputBayar: string) => {
                        let metodeBayar: number = Number(inputBayar);
                        let totalAkhir: number = totalBiaya;

                        //switch 2 (penggunaan switch kedua - min 3 case + default)
                        switch (metodeBayar){
                            case 1:
                                console.log("Metode bayar Tunai");
                                break;
                            case 2:
                                console.log("Metode bayar: E-Money");
                                console.log(`+ Biaya Admin E-Money: Rp ${BiayaAdmin}`);
                                break;
                            case 3:
                                console.log("Metode bayar: Kartu Kredit");
                                totalAkhir *= 1.02;
                                console.log("+ Surcharge 2% Kartu Kredit");
                                break;
                            default:
                                console.log("pilihan tidak valid, pembayaran diproses secara Tunai.")
                                break;        
                        }
                        console.log(`Total Tagihan Akhir : Rp ${totalAkhir}`);

                        //input 7: Uang Pembayaran
                        rl.question("Masukkan Uang Pembayaran : Rp ", (inputUang: string) => {
                            let uangDiabayar: number = Number(inputUang);

                            // IF 3 (Penggunaan IF ketiga)
                            // Validasi Pembayaran (kondisi majemuk &&, perbandingan >= dan !==)
                            let isLunas: boolean = uangDiabayar >= totalAkhir;

                            if (isLunas && uangDiabayar !== 0){
                                let kembalian: number = uangDiabayar - totalAkhir;
                                console.log("\n=====================================")
                                console.log("       PEMBAYARAN BERHASIL(LUNAS)      ")
                                console.log(`       Kembalian : Rp ${kembalian}`  )
                                console.log("\n=====================================")
                            } else {
                                let kekurangan: number = totalAkhir;
                                kekurangan -= uangDiabayar;
                                console.log("\n=====================================")
                                console.log("       PEMBAYARAN GAGAL / KURANG       ")
                                console.log(`       Kekurangan : Rp ${kekurangan}`  )
                                console.log("\n=====================================")
                            }
                            //menutup interface readline
                            rl.close();
                        })
                    })
                })

            })
        })
    })
})